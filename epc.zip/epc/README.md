# EPC Pipe HTS Classification Library (.NET 8)

A reusable C# library foundation for classifying iron and steel pipes imported into the United States.

## Important legal and data limitation

This repository is a software framework, not a complete legally validated tariff database or a guarantee of correct customs classification. It intentionally does **not** ship invented 6-, 8-, or 10-digit tariff lines or claim that its preliminary Chapter 73 router covers every legal exception.

Before production use, load the official HTSUS tariff schedule effective for the relevant entry date, encode and review the applicable legal notes/conditions, test against relevant CBP rulings, and have the rule set approved by a qualified customs professional. A single catalog match is returned as `Classified` only when its tariff row is explicitly marked `LegallyReviewed = true` and has a `LegalReviewReference`; otherwise it remains `ReviewRequired`.

Official sources:
- USITC HTS: https://hts.usitc.gov/
- CBP CROSS rulings: https://rulings.cbp.gov/
- CBP importing guidance: https://www.cbp.gov/trade/basic-import-export

## Features

- .NET 8 class library; no third-party runtime dependencies.
- Pipe specification model for material, grade, chemistry, manufacturing, welding, dimensions, purpose, finish, origin and evidence.
- Weight fields are optional and are not used by the default classification conditions.
- Synonym normalization for common supplier terms (SMLS, ERW, LSAW, HSAW, CS, SS, OD, WT).
- Fuzzy near-match helper for suggestions only; never used as a legal fact.
- Unit conversion helpers for common length and weight units.
- Input validation.
- Preliminary heading routing for 7303, 7304, 7305, 7306, 7307 and structural assembly review.
- Versioned tariff catalog model with effective dates and official unit-of-quantity field.
- Data-driven tariff conditions and candidate matching.
- Separate quantity reporting helper.
- Classification status, candidate list, missing data, warnings and reasoning.

## Solution tree

```text
EpcPipeHts/
├── src/
│   └── EpcPipeHts/
│       ├── Catalog/
│       │   └── HtsCatalog.cs
│       ├── Classification/
│       │   └── PipeClassificationEngine.cs
│       ├── Models/
│       │   ├── ClassificationResult.cs
│       │   ├── Enums.cs
│       │   ├── HtsTariffItem.cs
│       │   ├── PipeSpecification.cs
│       │   ├── PropertyEvidence.cs
│       │   └── TariffCondition.cs
│       ├── Normalization/
│       │   ├── PipeNormalizationHelper.cs
│       │   └── UnitConversionHelper.cs
│       ├── Reporting/
│       │   └── QuantityReportingHelper.cs
│       ├── Rules/
│       │   ├── HeadingRouter.cs
│       │   └── TariffConditionEvaluator.cs
│       ├── Serialization/
│       │   └── JsonDefaults.cs
│       ├── Validation/
│       │   └── PipeSpecificationValidator.cs
│       └── EpcPipeHts.csproj
├── samples/
│   └── EpcPipeHts.Demo/
│       ├── data/
│       │   └── hts-catalog.template.json
│       ├── Program.cs
│       └── EpcPipeHts.Demo.csproj
└── README.md
```

## Build

Install the .NET 8 SDK, then:

```bash
dotnet build src/EpcPipeHts/EpcPipeHts.csproj
dotnet run --project samples/EpcPipeHts.Demo/EpcPipeHts.Demo.csproj
```

The demo intentionally uses an empty catalog template. It demonstrates the workflow and returns no tariff code until official tariff records are loaded.

## Use from another project

Add a project reference:

```bash
dotnet add YourProject.csproj reference src/EpcPipeHts/EpcPipeHts.csproj
```

Create a `PipeSpecification`, load an `HtsCatalog`, then call:

```csharp
var engine = new PipeClassificationEngine(catalog);
var result = engine.Classify(pipe, DateOnly.FromDateTime(DateTime.UtcNow));
```

## Classification levels

- `Hs6Code`: international HS six-digit code.
- `Hts8Code`: US eight-digit tariff subheading.
- `Hts10Code`: US ten-digit statistical reporting number.

Codes are strings, not integers, so leading zeroes are preserved.

## Weight handling

Weight is optional in `PipeSpecification`. The classification matcher does not use weight unless a reviewed tariff condition is explicitly configured to do so. The separate `QuantityReportingHelper` reads the official unit of quantity from the selected tariff line. If the official unit is kilograms and net weight is missing, it reports the missing reporting quantity; it does not change the classification result.

Do not calculate a reportable customs weight from theoretical dimensions unless the applicable customs requirements permit that method and the data has been validated.

## Important implementation work before production

1. Download the current HTSUS data from USITC for the relevant entry date.
2. Import every applicable tariff line and retain the revision/effective dates.
3. Import section notes, chapter notes, US notes, statistical annotations and legal text.
4. Encode conditions only after legal review. The example `TariffCondition` model is an extensible mechanism, not an already complete set of legal rules. Mark a tariff row `LegallyReviewed = true` only after the full applicable rule set has been reviewed and tested; include a meaningful `LegalReviewReference`.
5. Add specific rules for relevant product families and competing headings, not just a broad 7303–7306 route.
6. Add regression tests against CBP CROSS rulings and customs-specialist-reviewed examples.
7. Evaluate Chapter 99 and AD/CVD measures separately for duty exposure. HTS classification alone does not establish all duties.
8. Have a customs specialist review/approve any result used for entry filing.

## Current scope

The initial router is deliberately limited to ordinary pipe-like goods and obvious exceptions. It is not a complete implementation of all Chapter 72, Chapter 73, Chapter 84, or other possible provisions. A product described commercially as a pipe may legally be a fitting, structural article, machinery part, or another article depending on its objective characteristics and the tariff rules.
