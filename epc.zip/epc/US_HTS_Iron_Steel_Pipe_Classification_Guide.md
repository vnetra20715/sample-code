# US HTS Classification of Iron and Steel Pipes

## 1. Purpose and scope

This document consolidates the requirements discussed for building a .NET 8 classification module for iron and steel pipes imported into the United States.

The system should determine, where the available facts and current legal tariff data support it:

- International HS code (6 digits)
- US HTSUS tariff subheading (8 digits)
- US HTSUS statistical reporting number (10 digits)

**Important limitation:** No program can guarantee a legally correct classification for every pipe from a short product description or incomplete technical data. The engine must return a verified result only when the applicable legal provisions and decisive product facts have been evaluated. Otherwise, it should return missing-information, multiple-candidate, or human-review status. A proposed code is not a binding CBP determination.

Primary official source: https://hts.usitc.gov/

## 2. US tariff framework and relevant chapters

The tariff schedule is the US Harmonized Tariff Schedule (HTSUS), maintained by the US International Trade Commission (USITC). The US uses the international HS structure through six digits, followed by US-specific tariff and statistical subdivisions.

### Primary Chapter 73 headings

| Heading | General description | How it relates to pipe work |
|---|---|---|
| 7301 | Sheet piling; welded angles, shapes and sections | May be relevant to certain profiles or structural sections, not ordinary pipe by default |
| 7302 | Railway or tramway track construction material | Usually outside ordinary pipe scope |
| 7303 | Tubes, pipes and hollow profiles of cast iron | Cast-iron pipe branch |
| 7304 | Seamless tubes, pipes and hollow profiles of iron or steel | Seamless pipe branch |
| 7305 | Other welded or similarly closed circular pipes, external diameter exceeding 406.4 mm | Large-diameter circular pipe branch |
| 7306 | Other tubes, pipes and hollow profiles of iron or steel | Other pipe and hollow-profile branch |
| 7307 | Tube or pipe fittings, such as elbows, couplings, sleeves and flanges | Fittings are considered separately from straight pipe |
| 7308 | Structures and parts of structures of iron or steel | Certain structural goods or assemblies may require review |
| 7309–7311 | Tanks, containers and vessels | Certain finished containers, not ordinary pipe |
| 7325–7326 | Other cast articles / other articles of iron or steel | Possible residual or article-specific provisions; not default pipe headings |

Chapter 72 is titled iron and steel and covers specified primary, semi-finished and worked steel products. It is relevant to material definitions and steel products, but is not a general fallback heading for finished pipes. Chapter 73 is the principal starting point for ordinary finished iron and steel pipes and pipe fittings.

Do not assume that every product marketed as a “pipe” belongs in 7303–7306. The actual imported article, its construction, condition, function, and the legal tariff text control. Fittings, structural assemblies, machinery parts, and other specially described articles may require a different heading or legal analysis.

Other chapters, such as Chapter 84, should be considered only when the imported article is legally described as a machinery part or other product covered there. Do not route an ordinary pipe to Chapter 84 solely because it is used in machinery.

## 3. Classification rules to encode

The classification process must apply the legal General Rules of Interpretation (GRIs), section notes, chapter notes, heading/subheading text, US notes, and statistical reporting provisions.

Key principles:

1. **GRI 1:** Classification is determined according to the terms of the headings and relevant section or chapter notes.
2. **GRI 2:** Consider incomplete or unfinished goods and goods presented unassembled or disassembled where the rule applies.
3. **GRI 3:** Where goods are prima facie classifiable under two or more headings, apply the prescribed rules for specificity, essential character, and last numerical order, as applicable.
4. **GRI 6:** Apply the relevant interpretive rules and legal notes at the subheading level.
5. **Section XV notes:** Review the definitions, exclusions, and rules relevant to base metals and articles of base metal.
6. **Chapter 72 notes:** Review relevant definitions and provisions concerning iron and steel, including alloy/non-alloy distinctions where applicable.
7. **Chapter 73 notes:** Apply Chapter 73 definitions, scope, and exclusions.
8. **US-specific notes and statistical annotations:** Review the current US tariff schedule and reporting requirements before assigning the final digits.

The software should store the legal text and rule references used for each result. A simplified decision tree is useful for routing, but it is not a substitute for applying all legal notes and GRIs.

### Initial heading-routing guide (not a final classification)

- Cast-iron pipe: investigate heading 7303.
- Seamless iron or steel pipe: investigate heading 7304.
- Other circular welded or similarly closed pipe with outside diameter greater than 406.4 mm: investigate heading 7305.
- Other iron or steel pipes and hollow profiles: investigate heading 7306.
- Pipe fittings: investigate heading 7307.
- Structural assemblies and other specially described articles: assess the relevant competing headings and legal notes.

The 406.4 mm threshold is a strict “exceeding” threshold. Exactly 406.4 mm does not exceed 406.4 mm. Do not apply this threshold outside the legal provision in which it appears.

## 4. Pipe properties to collect

Capture the following fields where applicable. Not every field is required for every tariff branch. The rules engine should identify which missing facts are material to the current decision.

### A. Product identity

- Product description as shown on invoice
- Commercial/trade name
- Manufacturer's product name
- Whether the imported article is a straight pipe, hollow profile, fitting, or assembly
- Whether imported alone or as part of a set/assembly

### B. Base material and metallurgy

- Base material: cast iron, wrought iron, or steel
- Steel type: non-alloy, alloy, or stainless
- Grade and material standard (ASTM, API, EN, ISO, etc.)
- Mill Test Certificate (MTC) details
- Chemical composition, including carbon, manganese, chromium, nickel, molybdenum and other relevant elements
- Whether claimed grade and chemical composition are consistent

Do not infer alloy or stainless classification solely from a marketing description. Use verified material specifications and the legal definitions in the applicable tariff notes.

### C. Manufacturing and construction

- Manufacturing process: seamless, welded, cast, riveted, or other
- Welding method where relevant: ERW, LSAW, HSAW/SAWH/SSAW, etc.
- Longitudinal, spiral/helical, or other seam configuration
- Hot-finished, cold-drawn, or other manufacturing condition
- Whether the article is closed by welding or another process
- Whether the product is finished, unfinished, unassembled, or incomplete

### D. Physical dimensions

- Cross-section: circular, square, rectangular, or other
- Outside diameter (OD), in original units and normalized millimetres
- Inside diameter (ID), if available
- Wall thickness, in original units and normalized millimetres
- Length
- Weight
- Shape and profile details

Preserve original dimensions and units. Do not calculate a missing legally relevant dimension from nominal pipe size or schedule unless the source specification supports that conversion. For example, Schedule 40 alone does not define wall thickness without the applicable nominal size and standard.

### E. Use and product function

- Intended use: oil, gas, water, structural, mechanical, pressure, or other
- Whether described as line pipe, casing, tubing, drill pipe, or another specialized pipe
- Fluid or material conveyed, if relevant
- Whether designed for a particular application
- Technical standard and specification
- Whether the article is actually a fitting or structural component rather than a pipe

Intended use can be relevant, but it must not replace the wording of the tariff provisions or applicable legal notes.

### F. Surface and end treatment

- Galvanized, coated, lined, painted, black, or other surface condition
- Plain, threaded, beveled, flanged, or other ends
- Attached fittings or accessories
- Whether the imported product is a fitting or a pipe with an accessory

### G. Import and evidence data

- Country of origin
- Manufacturer and mill
- Invoice description
- Packing list description
- Product datasheet
- MTC / chemical test report
- Drawings and dimensional sheets
- Applicable standard certificates
- Source document and page for every extracted property

Country of origin is important for origin rules, trade remedies, and duty calculation. It is not, by itself, a substitute for the physical facts used to classify the product.

## 5. Recommended C# data model

The following model is a starting point for a .NET 8 implementation. Nullable values are intentional: unknown facts should remain unknown rather than being guessed.

```csharp
public enum PipeMaterial
{
    Unknown,
    CastIron,
    WroughtIron,
    Steel
}

public enum SteelType
{
    Unknown,
    NonAlloy,
    Alloy,
    Stainless
}

public enum PipeManufacturing
{
    Unknown,
    Seamless,
    Welded,
    Cast,
    Riveted,
    Other
}

public enum PipeShape
{
    Unknown,
    Circular,
    Square,
    Rectangular,
    Other
}

public enum PipePurpose
{
    Unknown,
    LinePipe,
    Casing,
    Tubing,
    DrillPipe,
    Structural,
    Mechanical,
    Pressure,
    Conduit,
    Other
}

public class PipeSpecification
{
    // Product identity
    public string? ProductDescription { get; set; }
    public string? CommercialName { get; set; }

    // Material
    public PipeMaterial Material { get; set; }
    public SteelType SteelType { get; set; }
    public string? MaterialGrade { get; set; }
    public string? MaterialStandard { get; set; }

    // Manufacturing
    public PipeManufacturing Manufacturing { get; set; }
    public string? WeldingMethod { get; set; }
    public string? SeamConfiguration { get; set; }
    public bool? HotFinished { get; set; }
    public bool? ColdDrawn { get; set; }

    // Dimensions (normalized to mm; retain original values separately in production)
    public PipeShape Shape { get; set; }
    public decimal? OutsideDiameterMm { get; set; }
    public decimal? InsideDiameterMm { get; set; }
    public decimal? WallThicknessMm { get; set; }
    public decimal? LengthMm { get; set; }
    public decimal? WeightKg { get; set; }

    // Chemistry (percent by weight, where supported by source)
    public decimal? CarbonPercentage { get; set; }
    public decimal? ManganesePercentage { get; set; }
    public decimal? ChromiumPercentage { get; set; }
    public decimal? NickelPercentage { get; set; }
    public decimal? MolybdenumPercentage { get; set; }
    public Dictionary<string, decimal> OtherElements { get; set; } = new();

    // Use and product type
    public PipePurpose Purpose { get; set; }
    public string? IntendedUseDescription { get; set; }
    public string? FluidType { get; set; }
    public bool? PressureApplication { get; set; }

    // Surface and presentation
    public string? SurfaceTreatment { get; set; }
    public string? EndFinishing { get; set; }
    public bool IsPipeFitting { get; set; }
    public bool IsStructuralAssembly { get; set; }
    public bool? HasAttachedFittings { get; set; }

    // Origin and supporting documents
    public string? CountryOfOrigin { get; set; }
    public string? Manufacturer { get; set; }
    public string? MillTestCertificateReference { get; set; }
    public string? TechnicalDocumentReference { get; set; }

    // Provenance for extracted/entered properties
    public List<PropertyEvidence> Evidence { get; set; } = new();
}

public class PropertyEvidence
{
    public string PropertyName { get; set; } = "";
    public string OriginalValue { get; set; } = "";
    public string NormalizedValue { get; set; } = "";
    public string SourceDocument { get; set; } = "";
    public string? SourcePage { get; set; }
    public bool Verified { get; set; }
}
```

## 6. Wording normalization and mismatch handling

Manufacturers and suppliers use abbreviations, spelling variants, and different technical descriptions. Normalize language before rule evaluation, but never let fuzzy matching invent a technical fact.

Examples of terminology to recognize:

| Source wording | Normalized term |
|---|---|
| SMLS, SML, seamless tube | Seamless |
| ERW, E.R.W., electric resistance welded | Welded; method ERW |
| LSAW, SAWL | Longitudinal submerged arc welded |
| HSAW, SAWH, SSAW | Helical/spiral submerged arc welded |
| CS, carbon steel | Carbon steel (verify grade/composition) |
| SS, stainless | Stainless steel (verify grade/composition) |
| MS, mild steel | Mild steel (do not assume a tariff result from abbreviation alone) |
| OD, O.D. | Outside diameter |
| WT, W.T. | Wall thickness |
| NPS | Nominal pipe size |
| SCH 40 | Schedule 40; requires nominal size/standard to establish dimensions |

Recommended normalization behavior:

1. Preserve the original supplier wording.
2. Normalize case, punctuation, whitespace, common units, and approved abbreviations.
3. Use a controlled synonym dictionary maintained in a database.
4. Use fuzzy matching only to suggest possible terms for review.
5. Do not treat “ERW” and “seamless” as similar or interchangeable.
6. Do not infer material grade, chemistry, dimensions, or manufacturing process from an ambiguous trade name.
7. Record the source and verification state of every important property.

A basic helper:

```csharp
using System.Text.RegularExpressions;

public static class PipeNormalizationHelper
{
    private static readonly Dictionary<string, string> Synonyms =
        new(StringComparer.OrdinalIgnoreCase)
        {
            ["SMLS"] = "SEAMLESS",
            ["SML"] = "SEAMLESS",
            ["SEAMLESS TUBE"] = "SEAMLESS",
            ["SEAMLESS PIPE"] = "SEAMLESS",
            ["ERW"] = "ELECTRIC RESISTANCE WELDED",
            ["E.R.W."] = "ELECTRIC RESISTANCE WELDED",
            ["LSAW"] = "LONGITUDINAL SUBMERGED ARC WELDED",
            ["SAWL"] = "LONGITUDINAL SUBMERGED ARC WELDED",
            ["HSAW"] = "HELICAL SUBMERGED ARC WELDED",
            ["SAWH"] = "HELICAL SUBMERGED ARC WELDED",
            ["SSAW"] = "HELICAL SUBMERGED ARC WELDED",
            ["CS"] = "CARBON STEEL",
            ["SS"] = "STAINLESS STEEL",
            ["OD"] = "OUTSIDE DIAMETER",
            ["WT"] = "WALL THICKNESS"
        };

    public static string NormalizeText(string? input)
    {
        if (string.IsNullOrWhiteSpace(input))
            return string.Empty;

        var value = input.Trim().ToUpperInvariant();
        value = value.Replace("E.R.W.", "ERW")
                     .Replace("S.A.W.", "SAW");
        value = Regex.Replace(value, @"[^\w\s./%-]", " ");
        return Regex.Replace(value, @"\s+", " ").Trim();
    }

    public static string NormalizeTerm(string? input)
    {
        var value = NormalizeText(input);
        return Synonyms.TryGetValue(value, out var normalized)
            ? normalized
            : value;
    }
}
```

This is a starter dictionary, not an exhaustive industrial vocabulary. Extend it using reviewed supplier descriptions, standards, and technical documents.

## 7. Classification result model

A result should include codes, status, reasoning, missing data, candidates, and the HTS revision used.

```csharp
public enum ClassificationStatus
{
    Classified,
    MissingInformation,
    MultipleCandidates,
    ReviewRequired,
    NoMatchingTariff
}

public class PipeClassificationResult
{
    public ClassificationStatus Status { get; set; }

    public string? Hs6Code { get; set; }
    public string? Hts8Code { get; set; }
    public string? Hts10Code { get; set; }

    public string? Heading { get; set; }
    public string? Description { get; set; }
    public string? HtsRevision { get; set; }

    public List<string> MissingProperties { get; set; } = new();
    public List<string> Reasons { get; set; } = new();
    public List<string> LegalReferences { get; set; } = new();

    public List<string> CandidateCodes { get; set; } = new();
    public bool RequiresHumanReview { get; set; }
}
```

## 8. Initial heading-routing rules

The following is a deliberately limited first-stage routing function. It does not determine a final 6-, 8-, or 10-digit code.

```csharp
public class HeadingDecision
{
    public string? Heading { get; set; }
    public ClassificationStatus Status { get; set; }
    public List<string> MissingProperties { get; set; } = new();
    public List<string> Reasons { get; set; } = new();
}

public static class PipeHeadingRulesEngine
{
    public static HeadingDecision DetermineHeading(PipeSpecification pipe)
    {
        var result = new HeadingDecision();

        if (pipe.IsPipeFitting)
        {
            result.Heading = "7307";
            result.Status = ClassificationStatus.ReviewRequired;
            result.Reasons.Add("Evaluate the applicable pipe-fitting subheading.");
            return result;
        }

        if (pipe.IsStructuralAssembly)
        {
            result.Status = ClassificationStatus.ReviewRequired;
            result.Reasons.Add(
                "Assess structural article/assembly provisions, including heading 7308.");
            return result;
        }

        if (pipe.Material == PipeMaterial.Unknown)
        {
            result.MissingProperties.Add("Material");
            result.Status = ClassificationStatus.MissingInformation;
            return result;
        }

        if (pipe.Material == PipeMaterial.CastIron)
        {
            if (pipe.Manufacturing != PipeManufacturing.Cast)
            {
                result.Status = ClassificationStatus.ReviewRequired;
                result.Reasons.Add(
                    "Material and manufacturing information conflict; verify the product.");
                return result;
            }

            result.Heading = "7303";
            result.Status = ClassificationStatus.ReviewRequired;
            result.Reasons.Add(
                "7303 is an initial heading candidate; validate all legal notes and product facts.");
            return result;
        }

        if (pipe.Material != PipeMaterial.Steel &&
            pipe.Material != PipeMaterial.WroughtIron)
        {
            result.Status = ClassificationStatus.ReviewRequired;
            result.Reasons.Add("Material requires legal review.");
            return result;
        }

        if (pipe.Manufacturing == PipeManufacturing.Unknown)
        {
            result.MissingProperties.Add("Manufacturing");
            result.Status = ClassificationStatus.MissingInformation;
            return result;
        }

        if (pipe.Manufacturing == PipeManufacturing.Seamless)
        {
            result.Heading = "7304";
            result.Status = ClassificationStatus.ReviewRequired;
            result.Reasons.Add(
                "7304 is an initial heading candidate; validate the exact subheading.");
            return result;
        }

        if (pipe.Manufacturing == PipeManufacturing.Cast)
        {
            result.Status = ClassificationStatus.ReviewRequired;
            result.Reasons.Add(
                "Cast steel is not automatically cast iron; investigate the applicable provision.");
            return result;
        }

        if (pipe.Shape == PipeShape.Unknown)
        {
            result.MissingProperties.Add("Shape");
            result.Status = ClassificationStatus.MissingInformation;
            return result;
        }

        if (pipe.Shape == PipeShape.Circular)
        {
            if (!pipe.OutsideDiameterMm.HasValue)
            {
                result.MissingProperties.Add("OutsideDiameterMm");
                result.Status = ClassificationStatus.MissingInformation;
                return result;
            }

            if (pipe.OutsideDiameterMm.Value > 406.4m)
            {
                result.Heading = "7305";
                result.Status = ClassificationStatus.ReviewRequired;
                result.Reasons.Add(
                    "7305 is an initial candidate for other circular pipes exceeding 406.4 mm OD.");
                return result;
            }
        }

        result.Heading = "7306";
        result.Status = ClassificationStatus.ReviewRequired;
        result.Reasons.Add(
            "7306 is an initial candidate; confirm the product meets the heading terms and notes.");

        return result;
    }
}
```

**Important:** The routing code intentionally returns `ReviewRequired` even when it identifies a likely heading. It is not a complete legal implementation and must not be used to auto-release customs entries. The routing conditions must be expanded and validated against the full tariff schedule and CBP rulings.

## 9. Official HTS catalog data model

Never hardcode the 10-digit code in conditional statements. Load the official USITC schedule into a versioned database.

```csharp
public class HtsTariffItem
{
    public int Id { get; set; }

    public string Hs6 { get; set; } = "";
    public string Us8 { get; set; } = "";
    public string Us10 { get; set; } = "";

    public string Heading { get; set; } = "";
    public string Description { get; set; } = "";

    public string HtsRevision { get; set; } = "";
    public DateTime EffectiveFrom { get; set; }
    public DateTime? EffectiveTo { get; set; }

    public string? LegalNoteReferences { get; set; }
    public string? SourceReference { get; set; }

    public bool IsActive { get; set; }
}
```

The model above is a minimum catalog record. In production, create separate rule tables for dimensions, materials, manufacturing, end use where legally relevant, exclusions, and statistical annotations. Do not assume that the tariff description alone supplies all the decision criteria.

### Suggested database tables

- `HtsTariffItems`
- `HtsRevisions`
- `HtsSectionNotes`
- `HtsChapterNotes`
- `HtsAdditionalUsNotes`
- `HtsGeneralRules`
- `HtsClassificationRules`
- `HtsRuleConditions`
- `HtsSynonyms`
- `HtsCustomsRulings`
- `PipeSpecifications`
- `PipePropertyEvidence`
- `PipeClassificationHistory`

## 10. Tariff matching and final code selection

A production matching engine should:

1. Select the HTS revision effective on the relevant import/classification date.
2. Apply legal heading rules and notes.
3. Eliminate tariff provisions whose legal conditions are not met.
4. Identify any missing decisive facts.
5. Match the facts to the official 6-digit HS subheading.
6. Continue through the US 8-digit tariff subheading.
7. Continue to the 10-digit statistical reporting number.
8. Validate that the 8-digit code begins with the selected 6-digit code and the 10-digit code begins with the selected 8-digit code.
9. Retain all candidates and the reason each was excluded.
10. Return a single code only when the legal analysis and source data support it.

A simple database equality matcher is not enough. The rules engine must evaluate legal conditions, ranges, exclusions, and notes. A code hierarchy prefix check is a data-integrity check, not proof of legal classification.

## 11. Example application workflow

```csharp
var pipe = new PipeSpecification
{
    ProductDescription = "Seamless Carbon Steel Pipe",
    Material = PipeMaterial.Steel,
    SteelType = SteelType.NonAlloy,
    MaterialGrade = "ASTM A106 Grade B",
    Manufacturing = PipeManufacturing.Seamless,
    Shape = PipeShape.Circular,
    OutsideDiameterMm = 168.3m,
    InsideDiameterMm = 154.1m,
    WallThicknessMm = 7.1m,
    Purpose = PipePurpose.LinePipe,
    CountryOfOrigin = "India"
};

// Load the official tariff records and applicable legal rules
// for the relevant import date from your database.

var decision = PipeHeadingRulesEngine.DetermineHeading(pipe);

// Continue with the complete legal rules engine.
// Do not assign a final HTS code from the heading alone.
```

## 12. Official sources for the RAG and rules database

Use primary government sources first:

1. **USITC HTS:** https://hts.usitc.gov/  
   Official current US tariff schedule, including tariff text, notes, and downloadable data.

2. **USITC HTS archive:** https://hts.usitc.gov/  
   Use the available revisions and historical schedules to support effective-date classification.

3. **US Customs and Border Protection CROSS:** https://rulings.cbp.gov/  
   Search historical customs rulings for pipe material, construction, dimensions, manufacturing process, and intended use. A ruling is fact-specific; do not blindly reuse it for a different product.

4. **CBP:** https://www.cbp.gov/  
   Guidance on importing, classification, entry, and binding ruling processes.

For every ingested source, store its URL, title, publication/revision date, retrieval date, effective period, and relevant text/page or paragraph reference. Keep legal tariff data separate from explanatory commentary and commercial product descriptions.

## 13. Duty calculation is a separate function

The HTS classification is not the complete duty answer. After determining the correct classification, evaluate separately:

- Country-of-origin rules
- General and special duty rates
- Applicable Chapter 99 provisions
- Section 301 or other additional duties where applicable
- Antidumping and countervailing duty (AD/CVD) orders and scope
- Other trade measures, exclusions, and entry-date requirements

Do not infer AD/CVD applicability from the HTS code alone. Orders and scope descriptions may cover products by origin, producer/exporter, physical characteristics, and other conditions.

## 14. Recommended production safeguards

- Keep original supplier text and normalized values.
- Keep source evidence for every decisive property.
- Version tariff data and rules by effective date.
- Do not silently fill missing facts with defaults.
- Do not use fuzzy similarity to decide legal facts.
- Return multiple candidates when rules do not uniquely resolve classification.
- Require human review for conflicts, unusual products, or incomplete legal coverage.
- Log the rules, notes, data revision, and evidence used for each result.
- Regression-test against CBP rulings and reviewed classification examples.
- Provide a route for a customs specialist to approve or override a result with reasons.
- Consider a CBP binding ruling for significant unresolved classification questions.

## 15. Final architecture recommendation

For this project, use:

- **.NET 8 / C#:** deterministic classification and validation engine.
- **SQL Server:** versioned HTS catalog, legal notes, rules, synonyms, and audit history.
- **Azure OpenAI:** extraction of technical properties from invoices, product datasheets, MTCs, and supplier descriptions.
- **RAG:** retrieval of official HTS text, legal notes, and relevant CBP rulings.
- **Human review:** resolution of ambiguous or legally uncertain cases.

The LLM should extract and explain facts; the deterministic rules engine should apply validated legal rules; the official HTS catalog should supply the current code hierarchy. Do not allow the LLM to invent a tariff code.

**Bottom line:** Chapter 73 is the primary starting point for ordinary iron and steel pipes imported into the United States, but the engine must check the actual imported article and possible competing provisions. A reliable system should prefer “insufficient information” over a fabricated 10-digit code.
